{
    'name': 'Wizard Precios Oro Reporte',
    'version': '1.0',
    'depends': ['joyeria_reparaciones'],
    'data': [
        'wizard/wizard_set_precio_oros_view.xml',
        'wizard/wizard_set_precio_oros_action.xml',
    ],
    'installable': True,
}
