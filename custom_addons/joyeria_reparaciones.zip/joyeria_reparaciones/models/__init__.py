from . import reparacion
from . import joyeria_producto  # este es el nuevo archivo
from . import wizard_reporte_responsables
#from . import res_users

