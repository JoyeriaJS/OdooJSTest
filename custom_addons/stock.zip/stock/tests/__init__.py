# -*- coding: utf-8 -*-

from . import test_stock_flow
from . import test_product
from . import test_warehouse
from . import test_stock_location_search
from . import test_quant
from . import test_quant_inventory_mode
from . import test_generate_serial_numbers
from . import test_immediate
from . import test_inventory
from . import test_move
from . import test_move2
from . import test_move_lines
from . import test_multicompany
from . import test_robustness
from . import test_packing
from . import test_packing_neg
from . import test_proc_rule
from . import test_report
from . import test_report_stock_quantity
from . import test_report_tours
from . import test_stock_return_picking
from . import test_stock_lot
from . import test_picking_tours
from . import test_replenish
