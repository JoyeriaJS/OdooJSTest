/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { ActionPad } from "@point_of_sale/app/screens/product_screen/action_pad/action_pad";

patch(ActionPad.prototype, {
    setup() {
        super.setup();
        console.log("🔥 Botón de descuento cargado en ActionPad (v17 Community) 🔥");
    },

    onClickDiscount() {
        alert("Descuento funcionando en Community!");
    },
});
