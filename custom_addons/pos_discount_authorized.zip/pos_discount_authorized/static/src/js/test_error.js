console.log("TEST → si ves esto, el POS sí carga assets");
asdasdasdasd();  // ERROR intencional
