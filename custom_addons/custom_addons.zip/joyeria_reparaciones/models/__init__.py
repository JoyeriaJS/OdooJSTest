from . import reparacion
from . import joyeria_producto  # este es el nuevo archivo
from . import wizard_reporte_responsables
from . import reporte_salida_taller_wizard
from . import report_sales_by_store
from . import report_sales_by_vendedora
from . import report_monthly_rma_pos
#from . import res_users

